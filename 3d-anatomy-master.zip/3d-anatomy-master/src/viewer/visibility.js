// Visibility Management - Hide, isolate, transparency, restore
import * as THREE from 'three';
import { state, setHiddenParts, setTransparentParts, setIsolatedPart, getPartState, setPartState, batchPartStates, notify } from '../state/store.js';
import { getMeshRegistry, getMeshesBySystem, ownMeshesOf, withDescendants } from './loadModel.js';

// --- Material ownership ------------------------------------------------------
// Meshes share the 65 materials that came out of the GLB. A mesh only gets
// its own copy when it is actually modified, and goes back to the shared one
// when the modification is undone.

function materialsOf(mesh) {
  return Array.isArray(mesh.material) ? mesh.material : [mesh.material];
}

// Clone-on-write: returns the mesh's private materials, creating them once.
function ownMaterials(mesh) {
  if (!mesh.userData.ownsMaterial) {
    mesh.material = Array.isArray(mesh.material)
      ? mesh.material.map(mat => mat.clone())
      : mesh.material.clone();
    mesh.userData.ownsMaterial = true;
  }
  return materialsOf(mesh);
}

// What a mesh should look like when nothing is being done to it: faded if its
// structure is currently ghosted, otherwise the shared material from the GLB.
// Getting this wrong is what made hovering dissolve the ghost.
function restingMaterial(mesh, partId) {
  const base = mesh.userData.baseMaterial;
  if (!base) return null;

  if (ghostedIds?.has(partId)) {
    return Array.isArray(base) ? base.map(ghostVariantOf) : ghostVariantOf(base);
  }
  return base;
}

function releaseMaterial(mesh, partId) {
  if (mesh.userData.ownsMaterial) {
    materialsOf(mesh).forEach(mat => mat.dispose());
    mesh.userData.ownsMaterial = false;
  }

  const resting = restingMaterial(mesh, partId);
  if (resting) mesh.material = resting;
}

// Ghosting touches nearly every mesh at once, so it uses one shared faded
// variant per source material — 65 of them, not one per mesh.
const ghostVariants = new WeakMap();

function ghostVariantOf(material) {
  let ghost = ghostVariants.get(material);
  if (!ghost) {
    ghost = material.clone();
    ghost.transparent = true;
    ghost.opacity = GHOST_OPACITY;
    ghost.depthWrite = false;
    ghostVariants.set(material, ghost);
  }
  return ghost;
}

// Visibility is applied to the meshes a structure owns, never to its node:
// three.js propagates `visible` down the subtree, and 868 of the 2827
// structures sit inside another one, so touching the node would take unrelated
// structures with it.
function setStructureVisible(partId, visible) {
  ownMeshesOf(partId).forEach(mesh => { mesh.visible = visible; });

  const partState = getPartState(partId);
  partState.visible = visible;
  setPartState(partId, { visible });

  if (visible) {
    state.hiddenParts.delete(partId);
  } else {
    state.hiddenParts.add(partId);
  }
}

export function hidePart(partId) {
  if (!getMeshRegistry().has(partId)) return;

  // Hiding a structure hides what is nested inside it.
  batchPartStates(() => {
    withDescendants(partId).forEach(id => setStructureVisible(id, false));
  });

  notify('partHidden', partId);
}

export function showPart(partId) {
  if (!getMeshRegistry().has(partId)) return;

  batchPartStates(() => {
    withDescendants(partId).forEach(id => {
      setStructureVisible(id, true);
      restoreMaterial(id);
      setPartState(id, { opacity: 1 });
      state.transparentParts.delete(id);
    });
  });

  notify('partShown', partId);
}

// One structure's fade, without the notification. Both entry points go through
// here, so both clone before they write and both leave the same recorded state
// behind.
function applyTransparency(partId, opacity) {
  ownMeshesOf(partId).forEach(mesh => {
    if (opacity >= 1 && !mesh.userData.ownsMaterial) return;

    ownMaterials(mesh).forEach(mat => {
      mat.transparent = opacity < 1;
      mat.opacity = opacity;
      mat.depthWrite = opacity >= 1;
      mat.needsUpdate = true;
    });
  });

  const partState = getPartState(partId);
  partState.opacity = opacity;
  setPartState(partId, { opacity });

  if (opacity < 1) {
    state.transparentParts.add(partId);
  } else {
    state.transparentParts.delete(partId);
  }
}

export function setPartTransparency(partId, opacity) {
  if (!getMeshRegistry().has(partId)) return;

  opacity = THREE.MathUtils.clamp(opacity, 0, 1);
  applyTransparency(partId, opacity);

  notify('partTransparencyChanged', { partId, opacity });
}

export function isolatePart(partId) {
  if (!getMeshRegistry().has(partId)) return;

  const keep = new Set(withDescendants(partId));

  batchPartStates(() => {
    getMeshRegistry().forEach((node, id) => {
      const keeping = keep.has(id);
      setStructureVisible(id, keeping);
      if (!keeping) return;

      // Isolating is a "show" like every other one. Isolating a row while
      // something else is selected used to leave the isolated structure
      // wearing the ghost material: the one thing left on screen, at 12%
      // opacity with no depth write, over an empty viewport.
      restoreMaterial(id);

      // restoreMaterial hands the mesh back to the shared material, so a fade
      // the user asked for has to be re-applied rather than quietly dropped.
      const opacity = getPartState(id)?.opacity ?? 1;
      if (opacity < 1) applyTransparency(id, opacity);
    });
  });

  setIsolatedPart(partId);
  notify('partIsolated', partId);
}

export function restoreAllParts() {
  batchPartStates(() => {
    getMeshRegistry().forEach((node, id) => {
      setStructureVisible(id, true);
      restoreMaterial(id);

      const partState = getPartState(id);
      partState.opacity = 1;
      partState.selected = false;
      setPartState(id, { opacity: 1, selected: false });
    });
  });

  state.hiddenParts.clear();
  state.transparentParts.clear();
  setIsolatedPart(null);
  setHiddenParts([]);
  setTransparentParts([]);

  notify('allPartsRestored', true);
}

export function hideSystem(systemId) {
  batchPartStates(() => {
    getMeshesBySystem(systemId).forEach(node => {
      const partId = node.userData.partId;
      if (partId) setStructureVisible(partId, false);
    });
  });

  notify('systemHidden', systemId);
}

export function showSystem(systemId) {
  batchPartStates(() => {
    getMeshesBySystem(systemId).forEach(node => {
      const partId = node.userData.partId;
      if (!partId) return;

      setStructureVisible(partId, true);
      restoreMaterial(partId);
      setPartState(partId, { opacity: 1 });
      state.transparentParts.delete(partId);
    });
  });

  notify('systemShown', systemId);
}

export function setSystemTransparency(systemId, opacity) {
  opacity = THREE.MathUtils.clamp(opacity, 0, 1);

  batchPartStates(() => {
    getMeshesBySystem(systemId).forEach(node => {
      const partId = node.userData.partId;
      // Clone-on-write, exactly as for a single structure: this used to write
      // straight into the materials that came out of the GLB, which thousands
      // of meshes share, so one sweep of the depth slider faded structures
      // nobody asked about and nothing could put them back — releaseMaterial
      // hands the mesh to the same object the fade had already spoiled.
      if (partId) applyTransparency(partId, opacity);
    });
  });

  notify('systemTransparencyChanged', { systemId, opacity });
}

export function toggleSystemVisibility(systemId) {
  const { total, visible } = getSystemVisibilityState(systemId);
  if (total === 0) return;

  if (visible) {
    hideSystem(systemId);
  } else {
    showSystem(systemId);
  }
}

export function getSystemVisibilityState(systemId) {
  const nodes = getMeshesBySystem(systemId);
  if (nodes.length === 0) return { visible: false, total: 0, visibleCount: 0 };

  // Reads the owned meshes, because the node itself is never toggled.
  const visibleCount = nodes.filter(node => {
    const partId = node.userData.partId;
    return partId && ownMeshesOf(partId).some(mesh => mesh.visible);
  }).length;

  return {
    visible: visibleCount > 0,
    total: nodes.length,
    visibleCount
  };
}

// Restoring is now "point back at the shared material" rather than copying a
// dozen properties back one by one.
function restoreMaterial(partId) {
  ghostedIds?.delete(partId);
  ownMeshesOf(partId).forEach(mesh => releaseMaterial(mesh, partId));
}

// On a 277-piece skeleton an emissive tint on an occluded structure is simply
// not visible, so selecting also drops everything else back to a ghost. The
// user's own transparency settings are restored from partStates when it clears.
const GHOST_OPACITY = 0.12;
let ghostedIds = null;

export function ghostAllExcept(partId) {
  const keep = new Set(withDescendants(partId));
  const ghosted = new Set();

  getMeshRegistry().forEach((node, id) => {
    if (keep.has(id)) return;

    const meshes = ownMeshesOf(id);
    if (!meshes.some(mesh => mesh.visible)) return;

    ghosted.add(id);
  });

  // Recorded first: releaseMaterial reads this to decide what "resting" means.
  ghostedIds = ghosted;

  ghosted.forEach(id => {
    ownMeshesOf(id).forEach(mesh => releaseMaterial(mesh, id));
  });

  // The selected structure must read as solid even where it was see-through.
  keep.forEach(id => restoreMaterial(id));

  notify('ghostModeChanged', partId);
}

export function clearGhost() {
  if (!ghostedIds) return;

  const wasGhosted = [...ghostedIds];
  ghostedIds = null;

  wasGhosted.forEach(id => {
    restoreMaterial(id);

    // Give back a transparency the user had set before the ghost.
    const opacity = getPartState(id)?.opacity ?? 1;
    if (opacity < 1) setPartTransparency(id, opacity);
  });

  notify('ghostModeChanged', null);
}

// Highlighting only touches `emissive`, so it can be undone without disturbing
// a transparency the user set.
export function highlightMesh(partId, color = 0xffdf5d, intensity = 0.5) {
  ownMeshesOf(partId).forEach(mesh => {
    // Materials are shared, so tinting one in place would light up every mesh
    // using it; the highlighted structure gets its own copy instead.
    ownMaterials(mesh).forEach(mat => {
      mat.emissive = new THREE.Color(color);
      mat.emissiveIntensity = intensity;
      mat.needsUpdate = true;
    });
  });
}

export function clearHighlight(partId) {
  ownMeshesOf(partId).forEach(mesh => {
    if (!mesh.userData.ownsMaterial) return;

    const opacity = getPartState(partId)?.opacity ?? 1;

    // A structure the user made transparent keeps its own material; one that
    // was only hovered goes back to the shared one.
    if (opacity < 1) {
      materialsOf(mesh).forEach(mat => {
        const base = mesh.userData.baseMaterial;
        const source = Array.isArray(base) ? base[0] : base;
        if (source?.emissive) mat.emissive.copy(source.emissive);
        mat.emissiveIntensity = source?.emissiveIntensity ?? 1;
        mat.needsUpdate = true;
      });
    } else {
      releaseMaterial(mesh, partId);
    }
  });
}

export function clearAllHighlights() {
  getMeshRegistry().forEach((node, partId) => clearHighlight(partId));
}

export function getPartVisibility(partId) {
  if (!getMeshRegistry().has(partId)) return { visible: false, opacity: 0, selected: false };

  const partState = getPartState(partId);
  return {
    visible: ownMeshesOf(partId).some(mesh => mesh.visible),
    opacity: partState?.opacity ?? 1,
    selected: partState?.selected ?? false
  };
}

export function setPartVisibility(partId, visible) {
  if (!getMeshRegistry().has(partId)) return;
  setStructureVisible(partId, visible);
}